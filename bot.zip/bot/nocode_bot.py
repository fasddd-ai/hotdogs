"""
Nocode Discord ticket bot.

What it does
------------
- Listens for HTTPS POSTs from the Nocode panel (the panel calls this bot
  whenever a customer places an order).
- Creates a private ticket channel in your Discord server, adds the buyer +
  staff role, posts the order details, lets staff /close /claim /add.

How to host (cheapest options)
------------------------------
- Local machine while testing: just `python nocode_bot.py`. Use ngrok to
  expose it to the public internet so Vercel can reach it.
- Railway / Render / Fly.io / DigitalOcean App Platform: free or ~$5/mo.
  Set the env vars in their dashboard, deploy. They'll give you a public URL.
- Any cheap VPS: copy this file, `pip install -r requirements.txt`,
  run with `python nocode_bot.py` (use systemd/pm2/screen to keep alive).

Env vars (REQUIRED unless noted)
--------------------------------
DISCORD_BOT_TOKEN          your bot token
DISCORD_GUILD_ID           your Discord server ID
NOCODE_WEBHOOK_SECRET      shared secret between this bot and Nocode panel
                           (any random string — Nocode sends it as Bearer token)

DISCORD_TICKET_CATEGORY_ID (optional) put new tickets under this category
DISCORD_STAFF_ROLE_ID      (optional) role granted view to all tickets
PORT                       (optional) HTTP port to listen on, default 8000

Bot permissions needed (when inviting to your server)
-----------------------------------------------------
- View Channels
- Manage Channels
- Send Messages
- Embed Links
- Read Message History
- Use Application Commands
- Manage Permissions (so it can lock channels to specific users)

Invite URL format:
https://discord.com/api/oauth2/authorize?client_id=YOUR_BOT_CLIENT_ID&permissions=268503056&scope=bot+applications.commands
"""

import os
import asyncio
import discord
from discord import app_commands
from aiohttp import web

# ----- Config -----
TOKEN = os.environ.get("DISCORD_BOT_TOKEN", "")
GUILD_ID = int(os.environ.get("DISCORD_GUILD_ID", "0") or 0)
TICKET_CATEGORY_ID = int(os.environ.get("DISCORD_TICKET_CATEGORY_ID", "0") or 0)
STAFF_ROLE_ID = int(os.environ.get("DISCORD_STAFF_ROLE_ID", "0") or 0)
WEBHOOK_SECRET = os.environ.get("NOCODE_WEBHOOK_SECRET", "change-this-shared-secret")
HTTP_PORT = int(os.environ.get("PORT", "8000"))

if not TOKEN:
    raise SystemExit("DISCORD_BOT_TOKEN is not set. See top of file for env vars.")
if not GUILD_ID:
    print("[bot] WARNING: DISCORD_GUILD_ID not set — slash commands will be global (slow to register).")

intents = discord.Intents.default()
intents.members = True
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)


# ----- Bot lifecycle -----
@client.event
async def on_ready():
    print(f"[bot] logged in as {client.user} (id={client.user.id})")
    try:
        if GUILD_ID:
            guild = discord.Object(id=GUILD_ID)
            tree.copy_global_to(guild=guild)
            cmds = await tree.sync(guild=guild)
            print(f"[bot] synced {len(cmds)} commands to guild {GUILD_ID}")
        else:
            cmds = await tree.sync()
            print(f"[bot] synced {len(cmds)} global commands")
    except Exception as e:
        print(f"[bot] command sync failed: {e}")


# ----- Slash commands -----
@tree.command(name="close", description="Close this ticket and delete the channel.")
async def close_cmd(interaction: discord.Interaction):
    ch = interaction.channel
    if not isinstance(ch, discord.TextChannel) or not ch.name.startswith("ticket-"):
        await interaction.response.send_message("This isn't a ticket channel.", ephemeral=True)
        return
    await interaction.response.send_message(f"🔒 Ticket closed by {interaction.user.mention}. Deleting in 5s…")
    await asyncio.sleep(5)
    try:
        await ch.delete(reason=f"Ticket closed by {interaction.user}")
    except discord.Forbidden:
        await interaction.followup.send("I don't have permission to delete this channel.")


@tree.command(name="claim", description="Claim this ticket so other staff know you're handling it.")
async def claim_cmd(interaction: discord.Interaction):
    ch = interaction.channel
    if not isinstance(ch, discord.TextChannel) or not ch.name.startswith("ticket-"):
        await interaction.response.send_message("This isn't a ticket channel.", ephemeral=True)
        return
    await interaction.response.send_message(f"🤝 **{interaction.user.display_name}** has claimed this ticket.")


@tree.command(name="add", description="Add a user to this ticket channel.")
@app_commands.describe(user="The user to add")
async def add_cmd(interaction: discord.Interaction, user: discord.Member):
    ch = interaction.channel
    if not isinstance(ch, discord.TextChannel) or not ch.name.startswith("ticket-"):
        await interaction.response.send_message("This isn't a ticket channel.", ephemeral=True)
        return
    try:
        await ch.set_permissions(user, view_channel=True, send_messages=True, attach_files=True, read_message_history=True)
        await interaction.response.send_message(f"➕ Added {user.mention} to this ticket.")
    except discord.Forbidden:
        await interaction.response.send_message("I don't have permission to update channel perms.", ephemeral=True)


@tree.command(name="ping", description="Check if the bot is alive.")
async def ping_cmd(interaction: discord.Interaction):
    await interaction.response.send_message(f"🟢 Pong. Latency: {round(client.latency * 1000)}ms", ephemeral=True)


# ----- HTTP server (Nocode panel calls this) -----
async def create_ticket_handler(request: web.Request):
    auth = request.headers.get("Authorization", "")
    if auth != f"Bearer {WEBHOOK_SECRET}":
        return web.json_response({"error": "unauthorized"}, status=401)

    try:
        data = await request.json()
    except Exception:
        return web.json_response({"error": "invalid json"}, status=400)

    order_uid = data.get("order_uid")
    discord_id = data.get("discord_id")
    plan_name = data.get("plan_name", "—")
    amount = data.get("amount_usd", 0)
    username = data.get("username", "user")

    if not order_uid:
        return web.json_response({"error": "order_uid required"}, status=400)
    if not GUILD_ID:
        return web.json_response({"error": "DISCORD_GUILD_ID not set"}, status=500)

    guild = client.get_guild(GUILD_ID)
    if not guild:
        return web.json_response({"error": "bot is not in the configured guild"}, status=500)

    # base permission overwrites: hide from @everyone, allow bot + (optional) staff role
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        guild.me: discord.PermissionOverwrite(
            view_channel=True, send_messages=True, manage_channels=True,
            manage_messages=True, attach_files=True, embed_links=True,
            read_message_history=True
        )
    }
    if STAFF_ROLE_ID:
        role = guild.get_role(STAFF_ROLE_ID)
        if role:
            overwrites[role] = discord.PermissionOverwrite(
                view_channel=True, send_messages=True, attach_files=True,
                embed_links=True, read_message_history=True, manage_messages=True
            )

    # add the buyer if their Discord ID is known
    if discord_id:
        try:
            member = await guild.fetch_member(int(discord_id))
            overwrites[member] = discord.PermissionOverwrite(
                view_channel=True, send_messages=True, attach_files=True,
                embed_links=True, read_message_history=True
            )
        except Exception as e:
            print(f"[bot] couldn't fetch member {discord_id}: {e}")

    category = None
    if TICKET_CATEGORY_ID:
        cat = guild.get_channel(TICKET_CATEGORY_ID)
        if isinstance(cat, discord.CategoryChannel):
            category = cat

    channel_name = f"ticket-{order_uid.lower()}"

    try:
        channel = await guild.create_text_channel(
            name=channel_name,
            category=category,
            overwrites=overwrites,
            topic=f"Order {order_uid} | {plan_name} | ${amount}",
            reason=f"Auto ticket from Nocode for {username}"
        )
    except discord.Forbidden:
        return web.json_response({"error": "bot missing Manage Channels permission"}, status=500)
    except Exception as e:
        return web.json_response({"error": f"create channel failed: {e}"}, status=500)

    # initial message
    embed = discord.Embed(
        title=f"🎫 New Order — {order_uid}",
        color=0x5865F2,
        description=f"**Plan:** {plan_name}\n**Amount:** ${amount}\n**Buyer:** `{username}`"
    )
    embed.add_field(
        name="Next steps",
        value="Staff will reply shortly with payment instructions.\n"
              "Use `/close` to close this ticket once you're done.\n"
              "Use `/claim` to claim ownership · `/add @user` to bring someone in.",
        inline=False
    )
    mention = f"<@{discord_id}>" if discord_id else username
    try:
        await channel.send(content=f"{mention} 👋  Welcome — your order is below.", embed=embed)
    except Exception as e:
        print(f"[bot] initial message send failed: {e}")

    return web.json_response({
        "ok": True,
        "channel_id": str(channel.id),
        "channel_name": channel.name
    })


async def health_handler(request: web.Request):
    return web.json_response({
        "ok": True,
        "bot": str(client.user) if client.user else "starting",
        "guild_id": GUILD_ID,
        "ready": client.is_ready()
    })


async def start_http():
    app = web.Application()
    app.router.add_post("/create-ticket", create_ticket_handler)
    app.router.add_get("/health", health_handler)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", HTTP_PORT)
    await site.start()
    print(f"[bot] http server listening on 0.0.0.0:{HTTP_PORT}")


async def main():
    async with client:
        asyncio.create_task(start_http())
        await client.start(TOKEN)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("[bot] shutting down")
