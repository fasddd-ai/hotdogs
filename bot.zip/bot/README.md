# Nocode Discord Ticket Bot

A small Python bot that creates a private ticket channel in your Discord server every time a customer places an order on the Nocode panel. Provides `/close`, `/claim`, `/add` slash commands.

## Quick start (local test)

```bash
cd bot
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt

# Set env vars (Windows PowerShell):
$env:DISCORD_BOT_TOKEN = "your_token_here"
$env:DISCORD_GUILD_ID = "123456789012345678"
$env:NOCODE_WEBHOOK_SECRET = "pick-a-random-string-and-paste-it-into-nocode-config"

python nocode_bot.py
```

You should see:
```
[bot] http server listening on 0.0.0.0:8000
[bot] logged in as YourBotName#1234
[bot] synced 4 commands to guild ...
```

## Inviting the bot

Replace `YOUR_BOT_CLIENT_ID` with your bot's client ID (from Discord Developer Portal → your app → General Information):

```
https://discord.com/api/oauth2/authorize?client_id=YOUR_BOT_CLIENT_ID&permissions=268503056&scope=bot+applications.commands
```

Permission integer `268503056` = View Channels + Manage Channels + Send Messages + Embed Links + Read History + Use App Commands + Manage Permissions.

## Hosting options

The bot needs to be **always on** AND **publicly reachable over HTTPS** so the Vercel-hosted Nocode panel can call it.

| Option | Cost | Setup time |
|---|---|---|
| Railway.app | free/cheap | 5 min — paste repo URL, set env vars, deploy |
| Render.com | free/cheap | 5 min — same |
| Fly.io | free | 10 min — needs `fly.toml` |
| DigitalOcean / Linode VPS | $5/mo | 15 min — copy files, install Python, systemd service |
| Local + ngrok | free (dev only) | 2 min — `ngrok http 8000` for testing |

## Wiring it to Nocode

In `Nocode/lib/config.js` set:

```js
export const NOCODE_BOT_URL = 'https://your-bot-host.com';
export const NOCODE_BOT_SECRET = 'same-random-string-as-NOCODE_WEBHOOK_SECRET';
```

Push to GitHub. Vercel redeploys. Done — every new order POSTs to your bot, which creates the ticket.

## Slash commands

- `/close` — Close current ticket (deletes channel after 5s).
- `/claim` — Mark yourself as handling this ticket.
- `/add @user` — Add another user to the ticket channel.
- `/ping` — Health check.

## Optional: ticket category + staff role

If you set:

- `DISCORD_TICKET_CATEGORY_ID` — new tickets get nested under this category
- `DISCORD_STAFF_ROLE_ID` — anyone with this role can see all tickets

…then tickets are organized cleanly and your team can manage them.

To get IDs: enable Developer Mode (User Settings → Advanced → Developer Mode), right-click the category/role → Copy ID.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `unauthorized` from /create-ticket | Bot's `NOCODE_WEBHOOK_SECRET` doesn't match Nocode's `NOCODE_BOT_SECRET` |
| `bot missing Manage Channels` | Re-invite with the URL above (permission integer matters) |
| `bot is not in the configured guild` | Wrong `DISCORD_GUILD_ID`, or bot wasn't invited to that server |
| `couldn't fetch member` | Buyer's Discord ID is wrong, or bot lacks Server Members intent → enable in Developer Portal → Bot → Privileged Gateway Intents → Server Members Intent: ON |
